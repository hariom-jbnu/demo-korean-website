import { createFileRoute } from "@tanstack/react-router";
import SiteHeader from "@/components/site/SiteHeader";
import Hero from "@/components/site/Hero";
import CourseGrid from "@/components/site/CourseGrid";
import Roadmap from "@/components/site/Roadmap";
import Testimonials from "@/components/site/Testimonials";
import EmailSignup from "@/components/site/EmailSignup";
import SiteFooter from "@/components/site/SiteFooter";

export const Route = createFileRoute("/")({
  component: HomePage,
});

function HomePage() {
  return (
    <div className="min-h-screen bg-[#FFFDF9]">
      <SiteHeader />
      <main>
        <Hero />
        <CourseGrid />
        <Roadmap />
        <Testimonials />
        <EmailSignup />
      </main>
      <SiteFooter />
    </div>
  );
}