import { Facebook, Instagram, Music2, Youtube } from "lucide-react";
import { SITE, socials } from "@/components/site/links";

const socialIcons = {
  TikTok: Music2,
  Instagram,
  YouTube: Youtube,
  Facebook,
};

const explore = [
  { label: "Courses & books", href: "#courses" },
  { label: "Learning path", href: "#roadmap" },
  { label: "Student stories", href: "#stories" },
  { label: "Email fam", href: "#signup" },
];

export default function SiteFooter() {
  return (
    <footer className="border-t border-[#EDE3D6] bg-[#FBF6EE]">
      <div className="mx-auto w-full max-w-6xl px-6 py-12 sm:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <p className="font-display text-xl text-[#1C1917]">Korean with Ina</p>
            <p className="mt-3 max-w-[28ch] text-sm leading-relaxed text-[#6B564C]">
              Learning Korean can be simple and fun — one step at a time.
            </p>
          </div>

          <div>
            <p className="text-xs uppercase tracking-[0.16em] text-[#9C8779]">Explore</p>
            <ul className="mt-4 space-y-2.5 text-sm text-[#4A3A32]">
              {explore.map((item) => (
                <li key={item.href}>
                  <a className="transition-colors hover:text-[#BF3F42]" href={item.href}>
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-xs uppercase tracking-[0.16em] text-[#9C8779]">Contact</p>
            <ul className="mt-4 space-y-2.5 text-sm text-[#4A3A32]">
              <li>
                <a
                  className="break-all transition-colors hover:text-[#BF3F42]"
                  href={`mailto:${SITE.email}`}
                >
                  {SITE.email}
                </a>
              </li>
              <li>
                <a
                  className="transition-colors hover:text-[#BF3F42]"
                  href={SITE.tutoringHref}
                  target="_blank"
                  rel="noreferrer"
                >
                  1:1 Korean lesson
                </a>
              </li>
            </ul>

            <div className="mt-5 flex items-center gap-2">
              {socials.map((social) => {
                const Icon = socialIcons[social.label];
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={social.label}
                    className="flex h-8 w-8 items-center justify-center rounded-full border border-[#E4D6C4] text-[#6B564C] transition-colors hover:border-[#BF3F42] hover:text-[#BF3F42]"
                  >
                    {Icon ? <Icon className="h-3.5 w-3.5" /> : null}
                  </a>
                );
              })}
            </div>
          </div>
        </div>

        <p className="mt-10 border-t border-[#EDE3D6] pt-6 text-xs text-[#9C8779]">
          © {new Date().getFullYear()} Korean with Ina. All rights reserved.
        </p>
      </div>
    </footer>
  );
}