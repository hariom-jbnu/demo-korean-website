import { ArrowUpRight } from "lucide-react";
import { roadmapSteps } from "@/components/site/links";

export default function Roadmap() {
  return (
    <section
      id="roadmap"
      className="scroll-mt-20 border-y border-[#EDE3D6] bg-[#FBF6EE] py-16 sm:py-24"
    >
      <div className="mx-auto w-full max-w-6xl px-6 sm:px-8">
        <div className="max-w-xl">
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-[#BF3F42]">
            Learning path
          </p>
          <h2 className="mt-4 font-display text-[2rem] leading-[1.1] tracking-[-0.01em] text-[#1C1917] sm:text-[2.6rem]">
            Not sure where to start?
          </h2>
          <p className="mt-4 text-base leading-relaxed text-[#6B564C]">
            Six steps, in the order most students follow them. Pick the one that
            matches where you are now.
          </p>
        </div>

        <ol className="mt-12 grid gap-x-10 gap-y-8 sm:grid-cols-2 lg:grid-cols-3">
          {roadmapSteps.map((step) => (
            <li
              key={step.id}
              id={step.id}
              className="scroll-mt-24 border-t border-[#E4D6C4] pt-5"
            >
              <p className="font-display text-sm text-[#BF3F42]">{step.number}</p>
              <h3 className="mt-2 font-heading text-base font-semibold leading-snug text-[#1C1917]">
                {step.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-[#6B564C]">
                {step.body}
              </p>

              <div className="mt-3 space-y-1.5">
                {step.links.map((link) => (
                  <a
                    key={link.label}
                    href={link.href}
                    target="_blank"
                    rel="noreferrer"
                    className="group flex items-center gap-1.5 text-sm text-[#1C1917] transition-colors hover:text-[#BF3F42]"
                  >
                    <span className="border-b border-[#CFBFA9] pb-px group-hover:border-[#BF3F42]">
                      {link.label}
                    </span>
                    <ArrowUpRight className="h-3.5 w-3.5 shrink-0 text-[#A8917C]" aria-hidden="true" />
                  </a>
                ))}
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}