// Every destination points at Ina's existing site, so the remaster never breaks a live product page.
const BASE = "https://www.inakimie.com";
const MEDIA = "https://static.wixstatic.com/media";

export const SITE = {
  name: "Korean with Ina",
  email: "inakimie2822@gmail.com",
  poBox: "6230 Irvine Blvd, unit 1075, Irvine, CA 92620",
  tutoringHref: `${BASE}/koreantutoring`,
};

export const portraits = {
  main: `${MEDIA}/766fec_8ab74c5a1c564ccf93d1d9e0a865f497~mv2.jpg/v1/crop/x_0,y_0,w_750,h_995/fill/w_616,h_770,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/IMG_2845.jpg`,
};

export const courses = [
  {
    name: "Read Korean Like a Pro",
    kind: "Video course",
    icon: "play",
    promise:
      "Read, write and pronounce Hangul in two weeks, with step-by-step lessons and live Q&A support.",
    lessons: "39 video lessons",
    access: "Lifetime access",
    level: "Complete beginner",
    levelHref: "#step-foundations",
    href: `${BASE}/readkoreanlikeapro`,
    image: `${MEDIA}/6cb2c5_b99a9502139249069d27f518178150a9~mv2.png/v1/fill/w_817,h_498,al_c,q_90,usm_0.66_1.00_0.01,enc_avif,quality_auto/Product%20Mockups%20(eBooks%2C%20courses).png`,
  },
  {
    name: "Sentence Freedom",
    kind: "Video course",
    icon: "layers",
    promise:
      "Turn the words you know into real sentences — particles, tenses and word order, finally connected.",
    lessons: "57 video lessons",
    access: "Lifetime access",
    level: "Elementary",
    levelHref: "#step-sentences",
    href: `${BASE}/sentence-freedom`,
    image: `${MEDIA}/766fec_86712c6462b54693bfd282ccfb271002~mv2.png/v1/fill/w_655,h_372,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Product%20Mockups%20(2).png`,
  },
  {
    name: "The Game Changer",
    kind: "Grammar course",
    icon: "book",
    promise:
      "Build sentences on the spot with the patterns Korean speakers actually use, backed by hundreds of examples.",
    lessons: "331 pattern lessons",
    access: "Lifetime access",
    level: "Intermediate",
    levelHref: "#step-patterns",
    href: `${BASE}/gamechanger`,
    image: `${MEDIA}/6cb2c5_c15dc1d3d8f24d50aabb72e9a36d912b~mv2.png/v1/fill/w_674,h_382,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/COURSE%20Game%20Changer%20Mockup%20(1).png`,
  },
  {
    name: "Shadowing Studio",
    kind: "Speaking practice",
    icon: "mic",
    promise:
      "Train your ear, rhythm and pronunciation with guided shadowing dialogues you can repeat out loud.",
    lessons: "56 shadowing videos",
    access: "3-month program",
    level: "Any level",
    levelHref: "#step-speaking",
    href: `${BASE}/shadowing-studio`,
    image: `${MEDIA}/6cb2c5_b268b0ef9f1e4423a3b724cdf7309067~mv2.png/v1/fill/w_738,h_437,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Shadowing%20Practice%20Mockups%20(21).png`,
  },
  {
    name: "Korean Book Bundle",
    kind: "Ebook bundle",
    icon: "bundle",
    promise:
      "Five ebooks that cover reading, verbs, vocabulary, speaking and travel, plus four bonus books.",
    lessons: "5 ebooks + 4 bonuses",
    access: "Instant download",
    level: "All levels",
    levelHref: "#roadmap",
    href: `${BASE}/koreanebooks`,
    image: `${MEDIA}/6cb2c5_eb3728c8537c4e6dbe25f66543f94f04~mv2.png/v1/fill/w_547,h_446,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Book%20Bundle%20Mockup%20(4).png`,
  },
];

export const roadmapSteps = [
  {
    id: "step-foundations",
    number: "01",
    title: "Complete beginners",
    body:
      "The very first step is Hangul. Everything builds on this, so don't skip it.",
    links: [
      {
        label: "Read Korean Step by Step",
        note: "$7 book",
        href: `${BASE}/readkoreanstepbystep`,
      },
      {
        label: "Read Korean Like a Pro",
        note: "video course",
        href: `${BASE}/readkoreanlikeapro`,
      },
    ],
  },
  {
    id: "step-vocab",
    number: "02",
    title: "Grow your vocabulary",
    body:
      "Lack of vocabulary holds you back in every area of Korean. Start with foundation words you can use right away.",
    links: [
      {
        label: "Ultimate Vocabulary Power Pack",
        note: "2,206+ words",
        href: `${BASE}/vocab-power-pack`,
      },
    ],
  },
  {
    id: "step-speaking",
    number: "03",
    title: "Speaking & pronunciation",
    body:
      "Learn phrases you can use anywhere, and practise tone, rhythm and flow with real conversations.",
    links: [
      {
        label: "Speak Korean Anywhere",
        note: "essential phrases",
        href: `${BASE}/speakkoreananywhere`,
      },
      {
        label: "Shadowing Studio",
        note: "speaking practice",
        href: `${BASE}/shadowing-studio`,
      },
    ],
  },
  {
    id: "step-sentences",
    number: "04",
    title: "Make sentences",
    body:
      "You can read and you know some words. Now build your own sentences — present, past and future.",
    links: [
      {
        label: "Sentence Freedom",
        note: "particle lessons included",
        href: `${BASE}/sentence-freedom`,
      },
    ],
  },
  {
    id: "step-patterns",
    number: "05",
    title: "Expand your sentences",
    body:
      "Your sentences work, but they feel limited. Expand what you can say with the essential patterns.",
    links: [
      {
        label: "The Game Changer",
        note: "331 patterns",
        href: `${BASE}/gamechanger`,
      },
    ],
  },
  {
    id: "step-travel",
    number: "06",
    title: "Going to Korea?",
    body:
      "Get trip-ready with personal recommendations and the phrases you'll actually use on the ground.",
    links: [
      {
        label: "Korea Travel Guide",
        note: "restaurants, cafés, hotels",
        href: `${BASE}/koreatravelguide`,
      },
      {
        label: "Speak Korean Anywhere",
        note: "travel phrases",
        href: `${BASE}/speakkoreananywhere`,
      },
    ],
  },
];

export const testimonials = [
  {
    quote:
      "Going from learning the alphabet all the way to putting together full sentences is still crazy to me! I think it's amazing how far we've all come.",
    name: "Rachel F.",
  },
  {
    quote:
      "There is tangible growth in my Korean journey and I attribute it to Korean with Ina. It's one investment you can never go wrong on.",
    name: "E.G.",
  },
  {
    quote:
      "I love how we have such a positive learning environment, and I don't feel afraid to make a mistake, which makes learning more fun and enjoyable.",
    name: "Anthony A.",
  },
  {
    quote:
      "I loved how this class really challenged us to produce sentences and speak the language! Having a safe space to try and get live feedback was amazing.",
    name: "Vivian F.",
  },
  {
    quote:
      "As a former educator, I have so much respect for the work you do and the love you clearly have for teaching.",
    name: "Amanda H.",
  },
  {
    quote:
      "This class will ignite a fire for knowledge that will take you by surprise. Who knew learning could be so fun?",
    name: "Suzi R.",
  },
];

export const socials = [
  { label: "TikTok", href: "https://www.tiktok.com/@inakimieee" },
  { label: "Instagram", href: "https://www.instagram.com/inakimieee" },
  { label: "YouTube", href: "https://www.youtube.com/@koreanwithina" },
  { label: "Facebook", href: "https://www.facebook.com/koreanwithina" },
];