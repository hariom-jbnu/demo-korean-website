import { BookMarked, BookOpen, Layers, Mic, PlayCircle } from "lucide-react";
import { courses } from "@/components/site/links";
import CourseRow from "@/components/site/CourseRow";

const ICONS = {
  play: PlayCircle,
  layers: Layers,
  book: BookOpen,
  mic: Mic,
  bundle: BookMarked,
};

export default function CourseGrid() {
  return (
    <section id="courses" className="scroll-mt-20 bg-[#FFFDF9] pb-16 sm:pb-24">
      <div className="mx-auto w-full max-w-6xl px-6 sm:px-8">
        <div className="max-w-xl">
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-[#BF3F42]">
            Courses &amp; books
          </p>
          <h2 className="mt-4 font-display text-[2rem] leading-[1.1] tracking-[-0.01em] text-[#1C1917] sm:text-[2.6rem]">
            Choose what to learn next.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-[#6B564C]">
            Self-paced, clearly explained, and made for adults learning Korean
            from the beginning.
          </p>
        </div>

        <ul className="mt-10 border-b border-[#EDE3D6] sm:mt-12">
          {courses.map((course) => (
            <CourseRow
              key={course.name}
              course={course}
              Icon={ICONS[course.icon] ?? BookOpen}
            />
          ))}
        </ul>
      </div>
    </section>
  );
}