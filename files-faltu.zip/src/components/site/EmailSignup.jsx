import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { subscribeToEmailFam } from "@/lib/server-fns";

const EMPTY = { first_name: "", last_name: "", email: "" };

export default function EmailSignup() {
  const subscribe = useServerFn(subscribeToEmailFam);
  const [form, setForm] = useState(EMPTY);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");

  const setField = (key) => (event) =>
    setForm((prev) => ({ ...prev, [key]: event.target.value }));

  async function handleSubmit(event) {
    event.preventDefault();
    setError("");
    setStatus("saving");
    try {
      await subscribe({ data: form });
      setStatus("done");
      setForm(EMPTY);
    } catch {
      setStatus("error");
      setError("That didn't go through. Please try again, or email me directly.");
    }
  }

  const inputClass =
    "mt-2 w-full rounded-2xl border border-[#E4D2B9] bg-white px-4 py-3 text-sm text-[#3A2B26] placeholder:text-[#B3A08F] focus:border-[#BF3F42] focus:outline-none focus:ring-2 focus:ring-[#BF3F42]/20";

  return (
    <section
      id="signup"
      className="scroll-mt-20 border-t border-[#EDE3D6] bg-[#FBF6EE] px-6 py-16 sm:px-8 sm:py-24"
    >
      <div className="mx-auto w-full max-w-2xl rounded-2xl border border-[#EDE3D6] bg-[#FFFDF9] p-7 sm:p-10">
        {status === "done" ? (
          <div className="py-6 text-center" role="status">
            <p className="font-display text-2xl text-[#1C1917] sm:text-3xl">
              You're on the list.
            </p>
            <p className="mx-auto mt-3 max-w-sm text-sm leading-relaxed text-[#6B564C]">
              Look out for Korean tips, early access to new courses and news from
              the studio.
            </p>
          </div>
        ) : (
          <>
            <h2 className="font-display text-[1.8rem] leading-tight tracking-[-0.01em] text-[#1C1917] sm:text-[2.1rem]">
              Join the Email Fam
            </h2>
            <p className="mt-3 max-w-lg text-sm leading-relaxed text-[#6B564C] sm:text-[0.95rem]">
              Korean tips, early access to new courses and the things I only share
              with subscribers.
            </p>

            <form onSubmit={handleSubmit} className="mt-8">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="first-name"
                    className="text-xs font-medium uppercase tracking-[0.12em] text-[#8C7568]"
                  >
                    First name
                  </label>
                  <input
                    id="first-name"
                    name="first-name"
                    type="text"
                    required
                    maxLength={80}
                    autoComplete="given-name"
                    value={form.first_name}
                    onChange={setField("first_name")}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label
                    htmlFor="last-name"
                    className="text-xs font-medium uppercase tracking-[0.12em] text-[#8C7568]"
                  >
                    Last name
                  </label>
                  <input
                    id="last-name"
                    name="last-name"
                    type="text"
                    required
                    maxLength={80}
                    autoComplete="family-name"
                    value={form.last_name}
                    onChange={setField("last_name")}
                    className={inputClass}
                  />
                </div>
              </div>

              <div className="mt-4">
                <label
                  htmlFor="email"
                  className="text-xs font-medium uppercase tracking-[0.12em] text-[#8C7568]"
                >
                  Email (check spelling)
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  maxLength={254}
                  autoComplete="email"
                  value={form.email}
                  onChange={setField("email")}
                  className={inputClass}
                />
              </div>

              {error ? (
                <p className="mt-4 text-sm text-[#B3261E]" role="alert">
                  {error}
                </p>
              ) : null}

              <button
                type="submit"
                disabled={status === "saving"}
                className="mt-6 inline-flex min-h-[50px] w-full items-center justify-center rounded-full bg-[#BF3F42] px-8 font-heading text-sm font-medium text-[#FFFDF9] transition-colors hover:bg-[#A53236] disabled:cursor-not-allowed disabled:opacity-70 sm:w-auto"
              >
                {status === "saving" ? "Subscribing…" : "Subscribe"}
              </button>
            </form>
          </>
        )}
      </div>
    </section>
  );
}