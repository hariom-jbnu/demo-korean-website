export default function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-[#EDE3D6] bg-[#FFFDF9]/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-4 px-6 sm:h-[72px] sm:px-8">
        <a href="#top" className="font-display text-xl leading-none text-[#1C1917] sm:text-2xl">
          Korean with Ina
        </a>

        <nav className="hidden items-center gap-8 text-sm text-[#6B564C] sm:flex">
          <a className="transition-colors hover:text-[#1C1917]" href="#courses">
            Courses
          </a>
          <a className="transition-colors hover:text-[#1C1917]" href="#roadmap">
            Roadmap
          </a>
          <a className="transition-colors hover:text-[#1C1917]" href="#stories">
            Students
          </a>
          <a
            className="inline-flex min-h-[40px] items-center rounded-full bg-[#BF3F42] px-5 text-[#FFFDF9] transition-colors hover:bg-[#A53236]"
            href="#signup"
          >
            Email fam
          </a>
        </nav>

        <a
          className="inline-flex min-h-[36px] items-center rounded-full bg-[#BF3F42] px-4 text-xs text-[#FFFDF9] transition-colors hover:bg-[#A53236] sm:hidden"
          href="#courses"
        >
          Courses
        </a>
      </div>
    </header>
  );
}