import { ArrowRight, BookOpen, Infinity as InfinityIcon, PlayCircle } from "lucide-react";
import { Image } from "@/components/ui/image";
import { portraits } from "@/components/site/links";

const PROOF = [
  { icon: BookOpen, label: "5 books" },
  { icon: PlayCircle, label: "4 video courses" },
  { icon: InfinityIcon, label: "Lifetime access" },
];

export default function Hero() {
  return (
    <section id="top" className="bg-[#FFFDF9]">
      <div className="mx-auto grid w-full max-w-6xl items-center gap-12 px-6 py-16 sm:px-8 sm:py-24 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-[#BF3F42]">
            Learn Korean with Ina
          </p>

          <h1 className="mt-5 font-display text-[2.6rem] leading-[1.05] tracking-[-0.02em] text-[#1C1917] sm:text-[3.4rem] lg:text-[3.9rem]">
            Learning Korean can be simple and fun.
          </h1>

          <p className="mt-6 max-w-[48ch] text-base leading-relaxed text-[#6B564C] sm:text-[1.05rem]">
            Clear, structured courses for adult learners: read Hangul, grow your
            vocabulary and build sentences that sound like you.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3">
            <a
              href="#courses"
              className="inline-flex min-h-[50px] items-center justify-center gap-2 rounded-full bg-[#BF3F42] px-7 font-heading text-sm font-medium text-[#FFFDF9] transition-colors hover:bg-[#A53236]"
            >
              Browse courses
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </a>
            <a
              href="#roadmap"
              className="inline-flex items-center gap-2 font-heading text-sm font-medium text-[#1C1917] transition-colors hover:text-[#BF3F42]"
            >
              See the learning path
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </a>
          </div>

          <ul className="mt-10 flex flex-wrap gap-x-8 gap-y-3 border-t border-[#EDE3D6] pt-6 text-sm text-[#6B564C]">
            {PROOF.map((item) => (
              <li key={item.label} className="flex items-center gap-2">
                <item.icon className="h-4 w-4 text-[#BF3F42]" aria-hidden="true" />
                {item.label}
              </li>
            ))}
          </ul>
        </div>

        <div className="mx-auto w-full max-w-[320px] lg:max-w-none">
          <div className="aspect-[4/5] overflow-hidden rounded-2xl border border-[#EDE3D6] bg-[#FBF1E0]">
            <Image
              src={portraits.main}
              alt="Ina, Korean teacher and founder of Korean with Ina"
              className="h-full w-full"
              fittingType="fill"
            />
          </div>
        </div>
      </div>
    </section>
  );
}