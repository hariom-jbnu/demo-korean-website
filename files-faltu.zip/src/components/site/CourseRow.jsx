import { ArrowUpRight, Infinity as InfinityIcon, PlayCircle, Signal } from "lucide-react";
import { Image } from "@/components/ui/image";

export default function CourseRow({ course, Icon }) {
  return (
    <li className="group grid gap-5 border-t border-[#EDE3D6] py-8 sm:grid-cols-[190px_1fr_auto] sm:items-center sm:gap-8">
      <a
        href={course.href}
        target="_blank"
        rel="noreferrer"
        className="block overflow-hidden rounded-xl border border-[#F0E6D8] bg-[#FBF1E0] p-3"
      >
        <div className="aspect-[16/10]">
          <Image
            src={course.image}
            alt={`${course.name} materials`}
            className="h-full w-full"
            fittingType="contain"
          />
        </div>
      </a>

      <div className="min-w-0">
        <p className="flex items-center gap-2 text-xs font-medium uppercase tracking-[0.14em] text-[#BF3F42]">
          <Icon className="h-3.5 w-3.5" aria-hidden="true" />
          {course.kind}
        </p>

        <h3 className="mt-2 font-display text-xl leading-snug text-[#1C1917] sm:text-2xl">
          <a
            href={course.href}
            target="_blank"
            rel="noreferrer"
            className="transition-colors hover:text-[#BF3F42]"
          >
            {course.name}
          </a>
        </h3>

        <p className="mt-2 max-w-[58ch] text-sm leading-relaxed text-[#6B564C]">
          {course.promise}
        </p>

        <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-[#8C7568]">
          <span className="flex items-center gap-1.5">
            <PlayCircle className="h-3.5 w-3.5" aria-hidden="true" />
            {course.lessons}
          </span>
          <span className="flex items-center gap-1.5">
            <InfinityIcon className="h-3.5 w-3.5" aria-hidden="true" />
            {course.access}
          </span>
          <a
            href={course.levelHref}
            className="flex items-center gap-1.5 transition-colors hover:text-[#BF3F42]"
          >
            <Signal className="h-3.5 w-3.5" aria-hidden="true" />
            {course.level}
          </a>
        </div>
      </div>

      <a
        href={course.href}
        target="_blank"
        rel="noreferrer"
        aria-label={`Open ${course.name}`}
        className="hidden h-10 w-10 items-center justify-center rounded-full border border-[#EDE3D6] text-[#8C7568] transition-colors group-hover:border-[#BF3F42] group-hover:text-[#BF3F42] sm:flex"
      >
        <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
      </a>
    </li>
  );
}