import { testimonials } from "@/components/site/links";

export default function Testimonials() {
  return (
    <section id="stories" className="scroll-mt-20 bg-[#FFFDF9] py-16 sm:py-24">
      <div className="mx-auto w-full max-w-6xl px-6 sm:px-8">
        <div className="max-w-xl">
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-[#BF3F42]">
            Student stories
          </p>
          <h2 className="mt-4 font-display text-[2rem] leading-[1.1] tracking-[-0.01em] text-[#1C1917] sm:text-[2.6rem]">
            What students say.
          </h2>
        </div>

        <div className="mt-10 grid gap-x-10 gap-y-8 sm:mt-12 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((item) => (
            <figure key={item.name} className="border-t border-[#EDE3D6] pt-5">
              <blockquote className="text-[0.95rem] leading-relaxed text-[#4A3A32]">
                “{item.quote}”
              </blockquote>
              <figcaption className="mt-3 text-xs uppercase tracking-[0.12em] text-[#8C7568]">
                {item.name}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}